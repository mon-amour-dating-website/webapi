# pyblog for Web API class CSC406
example using restplus, sqlalchemy, marshmallow

v1 - api in a single file
v2 - codes are refactored

from flask import Flask
from flask_restplus import Api, Resource, fields
from flask_sqlalchemy import SQLAlchemy
from marshmallow import Schema, ValidationError, fields as ma_field
import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'maDb/postgres@PostgreSQL 11'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
api = Api(app, version='1.0', title='Blog Apis')

db = SQLAlchemy(app)

# blog namespace
ns_blog = api.namespace('blogs', description='Blog Post operations')
ns_user = api.namespace('users', description='User Account Operations')


class BlogPostModel(db.Model):
    """
    Blogpost Model
    """
    __tablename__ = 'Sign Up'

    username = db.Column(db.String primary_key=True)
    nickname = db.Column(db.String(128), nullable=False)
    dateOfBirth = db.Column(db.Integer, nullable=False)
    city = db.Column(db.String(128), nullable=False)
    country = db.Column(db.String(128), nullable=False)
    password = db.Column(db.Integer, nullable=False)
    confirmPassword = db.Column(db.Integer, nullable=False)

    modified_at = db.Column(
        db.DateTime, default=datetime.datetime.utcnow(),
        onupdate=datetime.datetime.utcnow)


class UserModel(db.Model):
    '''
    User Model
    '''
    # table name
    __tablename__ = 'ma table'

    username = db.Column(db.String, primary_key=True)
    password = db.Column(db.String(128), nullable=False)


# model for swagger
user_model = api.model('User', {
    'username': fields.Integer(readOnly=True, description='user unique identifier'),
    'password': fields.String(required=True, description='password')
})

blog_model = api.model('Blog', {
    'username': fields.Integer(readOnly=True, description='user unique identifier'),
    'nickname': fields.String,
    'dateOfBirth': fields.Integer,
    'city': fields.String,
    'country': fields.String,
    'password': fields.Integer,
    'confirmPassword': fields.Integer
})


class UserSchema(Schema):
    username = ma_field.Str(dump_only=True)
    password = ma_field.Int()


# route definition
@ns_user.route('/')
class Users(Resource):
    @ns_user.doc('list_user')
    @ns_user.marshal_list_with(user_model)
    def get(self):
        users = UserModel.query.all()
        userSchema = UserSchema(many=True)
        return userSchema.dump(users)

    @ns_user.doc('create_user')
    @ns_user.expect(user_model)
    def post(self):
        '''Create a new user'''
        try:
            user_model = api.payload
        except ValidationError as err:
            return {'error': err.messages}, 422

        # initialize fields
        username = user_model['name']
        password = user_model['password']

        emailStatus = UserModel.query.filter_by(email=email).first()
        if emailStatus is None:
            # create new author
            new_user = UserModel(username=username, password=password)
            db.session.add(new_user)
            db.session.commit()
            return {'result': 'user created'}, 201
        return {'error': 'email already existed'}, 400


if __name__ == '__main__':
    app.run(debug=True)

export interface DecodedToken {
  exp: number;
  iat: number;
  nameid: string;
  nbf: number;
  unique_name: string;
}

# My Dating App API

## About
This app is created by Eric Zheng Gong with .NetCore 2.0 webapi and Angular 6.

## Run
`ng serve`

## Build
`ng build --prod` Before doing this, Please change `outputPath` in angular.json.

## Features
* Bootstrap, Ngx-Bootstrap and Bootswatch theme
* Angular modules lazy-loading and pre-loading
* Angular routing guards and routing resolver
